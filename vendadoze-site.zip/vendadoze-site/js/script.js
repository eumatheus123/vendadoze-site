// Mobile Menu Toggle
document.addEventListener('DOMContentLoaded', function() {
    const mobileMenuBtn = document.querySelector('.mobile-menu-btn');
    const navMenu = document.querySelector('.nav-menu');

    if (mobileMenuBtn && navMenu) {
        mobileMenuBtn.addEventListener('click', function() {
            navMenu.classList.toggle('active');
        });
    }

    // Cart Dropdown Toggle
    const cartIcon = document.querySelector('.cart-icon');
    const cartDropdown = document.querySelector('.cart-dropdown');

    if (cartIcon && cartDropdown) {
        cartIcon.addEventListener('click', function(e) {
            e.stopPropagation();
            cartDropdown.classList.toggle('active');
        });

        document.addEventListener('click', function(e) {
            if (!cartIcon.contains(e.target) && !cartDropdown.contains(e.target)) {
                cartDropdown.classList.remove('active');
            }
        });
    }

    // Scroll Animation
    const fadeElements = document.querySelectorAll('.fade-in');
    const slideLeftElements = document.querySelectorAll('.slide-in-left');
    const slideRightElements = document.querySelectorAll('.slide-in-right');

    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }
        });
    }, { threshold: 0.1 });

    fadeElements.forEach(element => {
        element.style.opacity = '0';
        element.style.transition = 'opacity 1s ease-in-out';
        observer.observe(element);
    });

    slideLeftElements.forEach(element => {
        element.style.opacity = '0';
        element.style.transform = 'translateX(-50px)';
        element.style.transition = 'opacity 1s ease-in-out, transform 1s ease-in-out';
        observer.observe(element);
    });

    slideRightElements.forEach(element => {
        element.style.opacity = '0';
        element.style.transform = 'translateX(50px)';
        element.style.transition = 'opacity 1s ease-in-out, transform 1s ease-in-out';
        observer.observe(element);
    });
});

// Shopping Cart Functionality
class ShoppingCart {
    constructor() {
        this.items = [];
        this.total = 0;
    }

    addItem(product, quantity = 1) {
        const existingItem = this.items.find(item => item.id === product.id);
        
        if (existingItem) {
            existingItem.quantity += quantity;
        } else {
            this.items.push({
                id: product.id,
                name: product.name,
                price: product.price,
                image: product.image,
                quantity: quantity
            });
        }
        
        this.updateTotal();
        this.updateCartUI();
    }

    removeItem(productId) {
        this.items = this.items.filter(item => item.id !== productId);
        this.updateTotal();
        this.updateCartUI();
    }

    updateQuantity(productId, quantity) {
        const item = this.items.find(item => item.id === productId);
        if (item) {
            item.quantity = quantity;
            this.updateTotal();
            this.updateCartUI();
        }
    }

    updateTotal() {
        this.total = this.items.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    }

    updateCartUI() {
        const cartCount = document.querySelector('.cart-count');
        const cartItems = document.querySelector('.cart-items');
        const cartTotal = document.querySelector('.cart-total span:last-child');
        const emptyCart = document.querySelector('.empty-cart');
        
        if (cartCount && cartItems && cartTotal) {
            // Update cart count
            const totalItems = this.items.reduce((sum, item) => sum + item.quantity, 0);
            cartCount.textContent = totalItems;
            
            // Update cart items
            if (this.items.length === 0) {
                if (emptyCart) {
                    emptyCart.style.display = 'block';
                } else {
                    cartItems.innerHTML = '<p class="empty-cart">Seu carrinho está vazio</p>';
                }
            } else {
                if (emptyCart) {
                    emptyCart.style.display = 'none';
                }
                
                cartItems.innerHTML = this.items.map(item => `
                    <div class="cart-item">
                        <img src="${item.image}" alt="${item.name}" class="cart-item-image">
                        <div class="cart-item-info">
                            <div class="cart-item-title">${item.name}</div>
                            <div class="cart-item-price">R$ ${item.price.toFixed(2)} x ${item.quantity}</div>
                        </div>
                        <button class="cart-item-remove" data-id="${item.id}">
                            <i class="fas fa-times"></i>
                        </button>
                    </div>
                `).join('');
                
                // Add event listeners to remove buttons
                document.querySelectorAll('.cart-item-remove').forEach(button => {
                    button.addEventListener('click', (e) => {
                        const productId = e.currentTarget.dataset.id;
                        this.removeItem(productId);
                    });
                });
            }
            
            // Update cart total
            cartTotal.textContent = `R$ ${this.total.toFixed(2)}`;
        }
    }
}

// Initialize cart
const cart = new ShoppingCart();

// Add to cart function (to be called from product pages)
function addToCart(productId, productName, productPrice, productImage, quantity = 1) {
    cart.addItem({
        id: productId,
        name: productName,
        price: productPrice,
        image: productImage
    }, quantity);
    
    // Show confirmation message
    alert(`${productName} foi adicionado ao carrinho!`);
}

// Example product data (for testing)
const products = [
    {
        id: '1',
        name: 'Carne na Lata - 3,6kg',
        price: 299.90,
        image: 'images/carne_lata_2.jpg'
    }
];

// Function to add product from product page
function addToCartFromProductPage() {
    const quantity = parseInt(document.getElementById('quantity').value);
    addToCart('1', 'Carne na Lata - 3,6kg', 299.90, 'images/carne_lata_2.jpg', quantity);
}

